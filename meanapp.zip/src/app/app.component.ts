import { Component, OnInit } from '@angular/core';
import {HttpClient,HttpClientModule} from "@angular/common/http"
import { FormControl, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'meanproject';
  ourform= new FormGroup({
    name:new FormControl('')
  })
  constructor(private http:HttpClient)
  {

  }
  ngOnInit()
  {
        this.http.get("http://localhost:3000/api/posts").subscribe(res=>{
          console.log(res);
        })
  }
  sendform()
  {
      const data={name:this.ourform.value.name}
      this.http.post<{message:string}>("http://localhost:3000/api/posts",data).subscribe(
        res=>{
          console.log(res.message)
        }
      )
  }
}
