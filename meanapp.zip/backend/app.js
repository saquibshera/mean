const express=require("express")
const bodyparser=require('body-parser')
const mongoose=require('mongoose')
const Post=require('./models/posts')
const app = express()
mongoose.connect("mongodb+srv://shivam:7BBW5BDydakMwX0x@cluster0.sr1jh.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
.then(()=>{
    console.log("successfully connected")
})
.catch(()=>{
    console.log("connection failed");
})
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended:false}))
app.use((req,res,next)=>{
    res.setHeader("Access-Control-Allow-Origin",'*');
    res.setHeader("Access-Control-Allow-Headers","Origin,Content-Type,Accept");
    res.setHeader("Access-Control-Allow-Methods","POST,PUT,PATCH,DELETE,GET,OPTIONS")
    req.next();
})
app.post("/api/posts",(req,res,next)=>{
        const posts=new Post({
            name:req.body.name
        })
        posts.save()
        console.log(posts)
        res.status(201).json({
            message:"posted successfully",
         
        })
})
app.get("/api/posts",(req,res,next)=>{
      const posts=[
          {
              id:1,
              name:'shivam'
          },
          {
                id:2,
                name:'praveen'
          },
          {
            id:3,
            name:'Ankush'
          }
      ]
      res.status(200).json({
          message:"posts fetched successfully",
          posts:posts
      })
})

// app.use((req,res,next)=>{
//     res.send("this is express 10")
// })
module.exports=app;

